<?php 
/**
Plugin Name: Hot Line Chay vi trai tim
Version: 1.0
Author: Quang
 */

add_action( 'wp_footer', function(){
	?>
	<div id="chay-vi-trai-tim-blank">
		<a href="http://chayvitraitim.gamudaland.com.vn/" target="__blank">
			<img class="img-responsive" src="<?php echo plugins_url() ?>/Hotline-chayvitraitim/chay-vi-trai-tim.png" alt="Chạy vì trái tim" />
		</a>
	</div>
	<style type="text/css" media="screen">
		#chay-vi-trai-tim-blank{
			position: fixed;
			z-index: 100;
			top: 65px;
			right: 0;
		}
		#chay-vi-trai-tim-blank img{
			width: 100%;
		}
		@media screen and ( min-width: 767px ){
			#chay-vi-trai-tim-blank{
			}
		}
		@media screen and ( max-width: 768px ){
			#chay-vi-trai-tim-blank{
				right: -165px;
				top: 70px;
				opacity: .8;
				transition: all .3s ease-in-out;
				-moz-transition: all .3s ease-in-out;
				-webkit-transition: all .3s ease-in-out;
			}
			#chay-vi-trai-tim-blank:hover{
				right: 0;
				opacity: 1;
			}
		}
	</style>
	<?php
});
